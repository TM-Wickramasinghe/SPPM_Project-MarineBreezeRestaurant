<?php
include '../includes/security.php';
?>

<script>
if ( window.history.replaceState ) {
  window.history.replaceState( null, null, window.location.href );
}
</script> 
<?php

//delete feedback

if (isset($_POST['deletebtn'])) {
    $fID = $_POST['delete_fID'];

    $query = "DELETE  FROM feedback WHERE  fID='$fID' ";
    $query_run = mysqli_query($connection, $query);

    if ($query_run) {
        $_SESSION['status'] = "Feedback Successfully DELETED";
        $_SESSION['status_code'] = "success";
        header('Location: feedback.php');
    } else {
        $_SESSION['status'] = "Feedback is NOT DELETED";
        $_SESSION['status_code'] = "error";
        header('Location: feedback.php');
    }
}

